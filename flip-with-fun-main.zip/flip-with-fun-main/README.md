# flip-with-fun
This is the memory mind game developed using Html Css &amp; Javascript.
